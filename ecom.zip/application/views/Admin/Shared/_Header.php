<div id="logo-group">
	<!-- PLACE YOUR LOGO HERE -->
	<span id="logo"></span>
</div>