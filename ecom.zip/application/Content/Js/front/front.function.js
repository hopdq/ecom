function initHeader(url, callback){
	$.get(url, callback)
}