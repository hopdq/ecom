<?php
class ShoppingCartModel extends CI_Model{
	public function __construct(){
		parent::__construct();
	}
	public function init(){
		
	}
}