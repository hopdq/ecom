<?php
class FilterModel extends CI_Model{
	public $providers;
	public $price;
	public $attrs;
	public function __construct(){
		parent::__construct();
	}
}