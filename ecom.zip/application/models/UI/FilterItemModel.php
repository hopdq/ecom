<?php
class FilterItemModel extends CI_Model{
	public $title;
	public $code;
	public $items;
	public function __construct(){
		parent::__construct();
	}
}