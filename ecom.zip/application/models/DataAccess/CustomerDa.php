<?php
require_once 'system/core/Model.php';
class AttributeValueDa extends CI_Model{
	public function getCustomerInfo($customerId){
		// $this->load->database('default');
		// $this->db->select();
 	// 	$result = $query->result();
		// $this->db->close();
		// return $result;
	}
}